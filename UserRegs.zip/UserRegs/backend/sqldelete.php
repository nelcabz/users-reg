<?php
$fname=$_POST['firstname'];
$button=$_POST['delete'];

if($button=='Delete'){
	$dbhost='localhost';
	$dbuser='root';
	$dbpwrd='';
	$dbname='regdb';
	$conn=mysqli_connect($dbhost,$dbuser,$dbpwrd,$dbname)
	or die('Mysql Connection failed'.mysql_error());
	if(!$conn){
		die("Connection failed".mysql_error());
	}
	$sql="DELETE FROM users WHERE fname='$fname'";
	mysqli_query($conn, $sql);
}
?>

<html>
<head>
</head>
<body>
<h2>RETURN TO index.php</h2>
</body>
</html>