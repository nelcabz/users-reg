<?php
$fname=$_POST['firstname'];
$lname=$_POST['lastname'];
$accesslevel=$_POST['accesslevel'];
$address=$_POST['address'];
$password=$_POST['password'];
$button=$_POST['save'];

if($button=='Save'){
	$dbhost='localhost';
	$dbuser='root';
	$dbpwrd='';
	$dbname='regdb';
	$conn=mysqli_connect($dbhost,$dbuser,$dbpwrd,$dbname)
	or die('Mysql Connection failed'.mysql_error());
	if(!$conn){
		die("Connection failed".mysql_error());
	}
	$sql="INSERT INTO users(fname, lname, accesslevel, address, password) VALUES ('$fname', '$lname', '$accesslevel', '$address', '$password')";
	mysqli_query($conn, $sql);
}
?>

<html>
<head>
</head>
<body>
<h2>RETURN TO index.php</h2>
</body>
</html>