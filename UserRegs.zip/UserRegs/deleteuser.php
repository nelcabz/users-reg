<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css\style.css">
</head>
<body>

<h2>DELETE USER FORM </h2>
<p>Use this form to delete users from the system</p>

<div class="container">

<form action="backend\sqldelete.php" method="post">

<div class="row">
<div class="col-25">
<label for="fname">First Name</label>
</div>
<div class="col-75">
<input type="text" id="fname" name="firstname" placeholder="Delete user(s) with first name....">
</div>
</div>

<div class="row">
<input type="submit" value="Delete" name="delete">
</div>
</form>
</div>
</body>
</html>