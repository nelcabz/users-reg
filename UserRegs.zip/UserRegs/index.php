<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css\style.css">
</head>
<body>
<h2>Home</h2>
<p>Use this form to select Add User, View Users, Edit Users, Delete Users</p>

<div class="container">
<center>
<form action="adduser.php" method="post">
<div class="row">
<input type="submit" value="Add User" name="save">
</div>
</form>


<form action="viewuser.php" method="post">
<div class="row">
<input type="submit" value="View User" name="save">
</div>
</form>


<form action="edituser.php" method="post">
<div class="row">
<input type="submit" value="Edit User" name="save">
</div>
</form>


<form action="deleteuser.php" method="post">
<div class="row">
<input type="submit" value="Delete User" name="save">
</div>
</form>
</center>
</div>


</body>
</html>