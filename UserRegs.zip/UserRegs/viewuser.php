<html>
<head></head>
<body>
<?php
$dbhost='localhost';
	$dbuser='root';
	$dbpwrd='';
	$dbname='regdb';
	$conn=mysqli_connect($dbhost,$dbuser,$dbpwrd,$dbname)
	or die('Mysql Connection failed'.mysql_error());
	if(!$conn){
		die("Connection failed".mysql_error());
	}

$result = mysqli_query($conn,"SELECT * FROM users");
if(mysqli_num_rows($result) > 0){
?>
<table class='table table-bordered table-striped'>
<tr>
<td>First Name</td>
<td>Last Name</td>
<td>Access Level</td>
<td>Address</td>
</tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
<td><?php echo $row["fname"]; ?></td>
<td><?php echo $row["lname"]; ?></td>
<td><?php echo $row["accesslevel"]; ?></td>
<td><?php echo $row["address"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>
<?php
}
else{
echo "No result found";
}
?>
</body>
</html>
